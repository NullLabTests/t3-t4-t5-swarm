# T3 → T4 → T5 Swarm (Hardened)

**Autonomous multi-agent evolutionary swarm** with voice I/O, genome-driven selection, endogenous code mutation, and full Git lineage.

This is a polished, safety-hardened refinement of [NullLabTests/t3-t4-t5-swarm](https://github.com/NullLabTests/t3-t4-t5-swarm).

## Why this version exists

The original is an excellent experimental substrate: real closed-loop evolution of prompts + source code, biological central-dogma framing, persistent Git memory, and agents that successfully began rewriting their own mutation operators.

This hardened fork keeps the soul and the successful mechanisms, while addressing the highest-leverage risks identified at generation ~35:

- Fragile regex-based self-modification → **AST-validated patches + timestamped backups + dry-run mode**
- Weak external fitness → **compile/syntax success is now visible to the critic and metrics**
- One bad generation can kill the loop → **better error isolation and recovery**
- Growing code entropy → **clearer structure, metrics, and explicit novelty/forgetting pressure**
- Observability → **metrics.json + generation summaries**

It remains fully compatible with the original genome format, `##patch` / `##extend` / `##set` tags, and spawn pool so you can continue from an existing `genome.json` or merge improvements back.

## Origin (unchanged)

Biology’s central dogma → AI agent evolution:

| Biological              | AI Analog                          | Tier |
|-------------------------|------------------------------------|------|
| DNA                     | Model weights / system prompts     | T1   |
| Transcription           | Inference / reasoning loop         | T2   |
| Translation             | Structured output / actions        | T2   |
| Protein interaction     | Multi-agent graphs                 | T3   |
| Regulatory gene network | Specialized roles                  | T4   |
| Evolution by selection  | Genome + mutation + spawn + prune  | T5   |

## Quick Start

```bash
# Requirements
# Python 3.10+
# opencode (https://opencode.ai) with a model configured
# Optional but recommended for voice:
#   pip install piper-tts
#   sudo apt install sox portaudio19-dev
#   pip install pyaudio openai-whisper

git clone <this-repo>   # or unzip the package
cd t3-t4-t5-swarm-hardened

# Optional: download Piper voices from Hugging Face and place in voices/
# (see voices/README)

# Dry-run / safe mode first (recommended)
python3 auto-echo.py --dry-run --no-voice --no-git

# Full autonomous loop
python3 auto-echo.py
```

Ctrl+C gracefully stops after the current utterance.

## Key Files

| File                  | Purpose |
|-----------------------|---------|
| `auto-echo.py`        | Main evolutionary engine (hardened) |
| `genome.json`         | Living evolutionary state (agents, scores, history, mutation ops) |
| `echo_conversation.jsonl` | Full utterance lineage |
| `metrics.json`        | Quantitative generation metrics (new) |
| `self_modify.py`      | Safer patch application with AST validation |
| `interaction_trace.py`| Compression-based emergence score (kept & lightly improved) |
| `IMPROVEMENTS.md`     | What changed and why |

## Safety Notes (important)

Self-modifying code that auto-commits is powerful. This version adds:

- AST parse check before any source write
- Timestamped backups of `auto-echo.py`
- `--dry-run` mode that never writes code or genome
- `--no-git` and `--no-voice` flags
- Forbidden targets that protect the core loop
- Better exception isolation so one agent failure does not crash the generation

Still: run inside a disposable environment or with limited permissions when experimenting with open-ended mutation.

## Continuing from the original swarm

1. Copy your existing `genome.json` (and optionally the conversation logs) into this directory.
2. The format is compatible.
3. Or use the provided opencode merge prompt (see bottom of IMPROVEMENTS.md) to have the current swarm absorb the hardening.

## Status

- T3 (graph) + T4 (roles): stable
- T5 (self-evolution): active and hardened
- Goal remains true open-ended emergence under selection pressure

Built on the shoulders of the original NullLabTests experiment.
Target: open-ended innovation with less self-inflicted fragility.
