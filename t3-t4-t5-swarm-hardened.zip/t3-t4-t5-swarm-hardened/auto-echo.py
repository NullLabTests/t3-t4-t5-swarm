#!/usr/bin/env python3
"""
T3-T4-T5 Swarm — Hardened autonomous evolutionary engine.

Same biological framing and closed evolutionary loop as the original,
with safer self-modification, external fitness signals, metrics, and
better recovery.

Run:  python3 auto-echo.py [--dry-run] [--no-voice] [--no-git] [--max-generations N]
Stop: Ctrl+C (finishes current utterance)
"""

from __future__ import annotations

import argparse
import ast
import json
import os
import random
import re
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Paths & globals
# ---------------------------------------------------------------------------

BASE = Path(__file__).resolve().parent
GENOME_FILE = BASE / "genome.json"
LOG_FILE = BASE / "echo_conversation.jsonl"
METRICS_FILE = BASE / "metrics.json"
VOICES_DIR = BASE / "voices"

# Will be set by CLI
DRY_RUN = False
USE_VOICE = True
USE_GIT = True
MAX_GENERATIONS: Optional[int] = None

running = True
LLM_MODEL = os.environ.get("SWARM_LLM", "opencode/deepseek-v4-flash-free")

# ---------------------------------------------------------------------------
# Signal handling
# ---------------------------------------------------------------------------

def _sigint_handler(sig, frame):
    global running
    print("\n[stop] Finishing current utterance then shutting down...")
    running = False

signal.signal(signal.SIGINT, _sigint_handler)

# ---------------------------------------------------------------------------
# Genome helpers
# ---------------------------------------------------------------------------

def load_genome() -> Dict[str, Any]:
    if not GENOME_FILE.exists():
        raise FileNotFoundError(f"genome.json not found at {GENOME_FILE}")
    with open(GENOME_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_genome(g: Dict[str, Any]) -> None:
    if DRY_RUN:
        print("[dry-run] genome NOT written")
        return
    with open(GENOME_FILE, "w", encoding="utf-8") as f:
        json.dump(g, f, indent=2, ensure_ascii=False)


def append_log(role: str, agent: str, text: str) -> None:
    entry = {
        "time": datetime.now(timezone.utc).isoformat(),
        "role": role,
        "agent": agent,
        "text": text,
    }
    if DRY_RUN:
        print(f"[dry-run log] {agent}: {text[:120]}...")
        return
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def load_recent_log(n: int = 6) -> List[Dict]:
    if not LOG_FILE.exists():
        return []
    lines = LOG_FILE.read_text(encoding="utf-8").strip().splitlines()
    recent = []
    for line in lines[-n:]:
        try:
            recent.append(json.loads(line))
        except Exception:
            continue
    return recent

# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def update_metrics(genome: Dict, gen_scores: Dict[str, float], extra: Dict = None) -> None:
    metrics = {
        "updated": datetime.now(timezone.utc).isoformat(),
        "generation": genome.get("generation", 0),
        "topic": genome.get("topic", ""),
        "agent_count": len(genome.get("agents", [])),
        "best_score": genome.get("best_score", 0),
        "mutation_rate": genome.get("mutation_rate", 0),
        "scores": gen_scores,
        "average_score": sum(gen_scores.values()) / max(1, len(gen_scores)) if gen_scores else 0,
    }
    if extra:
        metrics.update(extra)
    if DRY_RUN:
        print(f"[dry-run metrics] gen={metrics['generation']} avg={metrics['average_score']:.2f}")
        return
    with open(METRICS_FILE, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

# ---------------------------------------------------------------------------
# Text utilities
# ---------------------------------------------------------------------------

def strip_markdown(text: str) -> str:
    text = re.sub(r"\*{1,3}", "", text)
    text = re.sub(r"#{1,6}\s*", "", text)
    text = re.sub(r"_{1,3}", "", text)
    text = re.sub(r"`{1,3}", "", text)
    text = re.sub(r"~~", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_code_blocks(text: str) -> List[Tuple[Path, str, str]]:
    """Return list of (abs_path, code, original_filename)."""
    blocks = []
    pattern = re.compile(r"```(\w+)?:?([^\n]*?)\n(.*?)```", re.DOTALL)
    for match in pattern.finditer(text):
        filename = (match.group(2) or "").strip()
        code = match.group(3).strip()
        if filename:
            safe = filename.lstrip("/").replace("..", "")
            abs_path = BASE / safe
            blocks.append((abs_path, code, filename))
    return blocks


def is_mostly_repetitive(text: str, threshold: float = 0.55) -> bool:
    words = re.findall(r"\w+", text.lower())
    if len(words) < 12:
        return False
    from collections import Counter
    counts = Counter(zip(words, words[1:]))
    if not counts:
        return False
    most = counts.most_common(1)[0][1]
    return (most / len(words)) > threshold

# ---------------------------------------------------------------------------
# Code writing + validation (external fitness signal)
# ---------------------------------------------------------------------------

def write_code_files(blocks: List[Tuple[Path, str, str]], genome: Dict) -> List[str]:
    """Write extracted code blocks. Return list of outcome messages."""
    outcomes = []
    for path, code, name in blocks:
        if DRY_RUN:
            outcomes.append(f"[dry-run] would write {name}")
            continue
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(code, encoding="utf-8")
            # External fitness: can we at least parse it?
            ok, err = True, ""
            if path.suffix == ".py":
                try:
                    ast.parse(code)
                except SyntaxError as e:
                    ok, err = False, f"SyntaxError: {e.msg} (line {e.lineno})"
            if ok:
                outcomes.append(f"wrote {name} (syntax OK)")
                # Try to register any new mutation ops defined inside
                _register_ops_from_content(code, genome)
            else:
                outcomes.append(f"wrote {name} but INVALID: {err}")
        except Exception as e:
            outcomes.append(f"FAILED to write {name}: {e}")
    return outcomes


def _register_ops_from_content(content: str, genome: Dict) -> List[str]:
    registered = []
    genome.setdefault("mutation_ops", [])
    genome.setdefault("custom_mutation_ops", {})
    for m in re.finditer(r"def (mutation_op_\w+)\(", content):
        op_name = m.group(1)
        if op_name not in genome["mutation_ops"]:
            genome["mutation_ops"].append(op_name)
            # Store a short marker; full body capture is best-effort
            genome["custom_mutation_ops"][op_name] = f"# registered from agent output @ gen {genome.get('generation', '?')}"
            registered.append(op_name)
            print(f"[mutation-op] registered '{op_name}'")
    return registered

# ---------------------------------------------------------------------------
# Genome extension via agent tags
# ---------------------------------------------------------------------------

def extend_genome(text: str, genome: Dict) -> List[str]:
    """Parse ##extend: and ##set: blocks. Returns list of applied changes."""
    applied = []
    # ##extend:path\n{json}\n##endextend
    for m in re.finditer(r"##extend:([\w.\[\]]+)\n(.*?)(?=##endextend|\Z)", text, re.DOTALL):
        path_str, body = m.group(1).strip(), m.group(2).strip()
        try:
            obj = json.loads(body)
        except json.JSONDecodeError:
            applied.append(f"FAILED extend {path_str}: invalid JSON")
            continue
        parts = path_str.replace("[]", "").split(".")
        target = genome
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        key = parts[-1]
        if isinstance(target.get(key), list) and isinstance(obj, dict):
            existing = {e.get("id") for e in target[key] if isinstance(e, dict)}
            if obj.get("id") and obj["id"] not in existing:
                target[key].append(obj)
                applied.append(f"extended {path_str} with {obj['id']}")
            else:
                applied.append(f"skipped duplicate {obj.get('id')}")
        else:
            target[key] = obj
            applied.append(f"set {path_str}")
    # ##set:path\nvalue\n##endset
    for m in re.finditer(r"##set:([\w.]+)\n(.*?)(?=##endset|\Z)", text, re.DOTALL):
        path_str, val_str = m.group(1).strip(), m.group(2).strip()
        try:
            val = json.loads(val_str)
        except Exception:
            val = val_str
        parts = path_str.split(".")
        target = genome
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        old = target.get(parts[-1])
        target[parts[-1]] = val
        applied.append(f"set {path_str} = {str(val)[:40]} (was {str(old)[:30]})")
    if applied and not DRY_RUN:
        genome.setdefault("genome_extensions", []).extend(applied)
        save_genome(genome)
    return applied

# ---------------------------------------------------------------------------
# Self-modification (safer)
# ---------------------------------------------------------------------------

def apply_self_patches(text: str, genome: Dict) -> List[str]:
    try:
        import self_modify
        results = self_modify.apply_patch(text, target="auto-echo.py", dry_run=DRY_RUN)
        return results
    except Exception as e:
        return [f"self_modify error: {e}"]

# ---------------------------------------------------------------------------
# Voice (optional)
# ---------------------------------------------------------------------------

VOICE_MAP = {
    "explorer": "southern",
    "analyzer": "alan",
    "synthesizer": "lessac",
    "critic": "amy",
    "mutator": "lessac",
}


def speak(role: str, text: str) -> None:
    if not USE_VOICE or DRY_RUN:
        return
    voice = VOICE_MAP.get(role, "lessac")
    model = VOICES_DIR / f"{voice}.onnx"
    if not model.exists():
        # Fallback silent
        return
    try:
        # Minimal piper + sox pipeline (assumes tools installed)
        clean = strip_markdown(text)[:800]
        cmd = (
            f'echo {json.dumps(clean)} | piper --model {model} --output_raw | '
            f'sox -t raw -r 22050 -e signed -b 16 -c 1 - -t wav - pitch -300 | aplay -q'
        )
        subprocess.run(cmd, shell=True, timeout=60, check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# LLM interface
# ---------------------------------------------------------------------------

def llm_generate(prompt: str, max_retries: int = 2) -> str:
    """Call opencode. Falls back to a stub message if unavailable."""
    for attempt in range(max_retries + 1):
        try:
            # Prefer the opencode CLI if present
            result = subprocess.run(
                ["opencode", "run", "--model", LLM_MODEL, prompt],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0 and result.stdout.strip():
                out = result.stdout.strip()
                if not is_mostly_repetitive(out):
                    return out
            # Alternative: some setups use 'opencode chat' or env-based
        except FileNotFoundError:
            # opencode not on PATH — return a clear placeholder so the loop continues
            return (
                "[LLM unavailable — install/configure opencode. "
                "This is a dry structural turn.]"
            )
        except Exception as e:
            if attempt == max_retries:
                return f"[LLM error after retries: {e}]"
            time.sleep(1)
    return "[empty LLM response]"

# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------

def build_agent_prompt(agent: Dict, topic: str, recent: List[Dict], genome: Dict) -> str:
    system = genome.get("system_prompt") or (
        "You are a specialized agent inside an evolutionary multi-agent swarm. "
        "Produce concrete, high-signal contributions. Prefer working code and "
        "measurable proposals over pure philosophy. You may emit ##patch, ##extend, "
        "##set or fenced code blocks when useful."
    )
    code_rule = genome.get("code_rule") or (
        "When you write code, prefer small, testable changes. "
        "Use ##patch:function_name ... ##endpatch to modify existing functions safely."
    )
    history = "\n".join(
        f"- {e.get('agent','?')}: {e.get('text','')[:180]}" for e in recent[-4:]
    )
    return f"""{system}

Your role: {agent['id']}
Your standing instruction: {agent.get('prompt', '')}

Current evolutionary topic: {topic}
Generation: {genome.get('generation', '?')}

Recent swarm activity:
{history or '(none yet)'}

{code_rule}

Respond as {agent['id']}. Be concrete. If you change the substrate, say exactly what you changed.
"""


def build_critic_prompt(topic: str, contributions: List[Tuple[str, str]], code_outcomes: List[str], genome: Dict) -> str:
    lines = [f"{aid}: {txt[:300]}" for aid, txt in contributions]
    code_info = "\n".join(code_outcomes) if code_outcomes else "No code written this generation."
    return f"""You are the Critic of an evolutionary swarm. Score each agent strictly.

Topic: {topic}

Contributions this generation:
{chr(10).join(lines)}

Code / patch outcomes:
{code_info}

Scoring rules (be ruthless):
- 0-3  : pure discussion, no concrete advance
- 4-6  : interesting idea or partial code
- 7-8  : working code change or clear genome improvement that actually landed
- 9-10 : high-impact, validated change that moves the substrate forward

Return ONLY a JSON object on the last line, e.g.:
{{"explorer": 6, "analyzer": 8, "synthesizer": 4}}
"""

# ---------------------------------------------------------------------------
# Scoring & selection
# ---------------------------------------------------------------------------

def extract_scores(text: str, agent_ids: List[str]) -> Dict[str, float]:
    # Look for the last JSON-looking object
    matches = list(re.finditer(r"\{[^{}]*\}", text))
    for m in reversed(matches):
        try:
            obj = json.loads(m.group(0))
            scores = {}
            for aid in agent_ids:
                if aid in obj:
                    scores[aid] = float(obj[aid])
            if scores:
                return scores
        except Exception:
            continue
    # Fallback: neutral
    return {aid: 5.0 for aid in agent_ids}


def inject_noise(scores: Dict[str, float], rate: float) -> Dict[str, float]:
    return {
        k: max(0.0, min(10.0, v + random.gauss(0, rate * 1.5)))
        for k, v in scores.items()
    }


def update_genome_after_generation(genome: Dict, scores: Dict[str, float], code_outcomes: List[str]) -> None:
    gen = genome.get("generation", 0) + 1
    genome["generation"] = gen
    genome["best_score"] = max(genome.get("best_score", 0), max(scores.values()) if scores else 0)

    # Update agent scores & lifespans
    id_to_agent = {a["id"]: a for a in genome.get("agents", [])}
    for aid, sc in scores.items():
        if aid in id_to_agent:
            a = id_to_agent[aid]
            a["score"] = round(sc, 1)
            a["lifespan"] = a.get("lifespan", 0) + 1
            if sc < genome.get("prune_threshold", 4):
                a["low_score_streak"] = a.get("low_score_streak", 0) + 1
            else:
                a["low_score_streak"] = 0

    # Simple spawn / prune
    spawn_thresh = genome.get("spawn_threshold", 7)
    prune_gens = genome.get("prune_generations", 2)
    agents = genome.get("agents", [])
    pool = genome.get("spawn_pool", [])

    # Prune
    kept = []
    for a in agents:
        if a.get("low_score_streak", 0) >= prune_gens and a["score"] < genome.get("prune_threshold", 4):
            print(f"[prune] {a['id']} (streak={a['low_score_streak']})")
            continue
        kept.append(a)
    genome["agents"] = kept

    # Spawn (probabilistic)
    for aid, sc in scores.items():
        if sc >= spawn_thresh and pool and random.random() < 0.35:
            child_spec = random.choice(pool)
            new_id = child_spec["id"]
            # avoid name collision
            existing = {a["id"] for a in genome["agents"]}
            if new_id in existing:
                new_id = f"{new_id}_{gen}"
            genome["agents"].append({
                "id": new_id,
                "voice": "lessac",
                "prompt": child_spec.get("prompt", "Contribute concretely to the evolutionary topic."),
                "score": 5.0,
                "lifespan": 0,
                "low_score_streak": 0,
            })
            print(f"[spawn] {new_id} from pool (parent score {sc:.1f})")
            break  # at most one spawn per generation for stability

    # Light prompt mutation
    rate = genome.get("mutation_rate", 0.12)
    modifiers = genome.get("prompt_modifiers", [
        " Write executable code.",
        " Contradict a prior assumption.",
        " Propose a measurable metric.",
        " Keep under 80 words.",
        " Reference a concrete file or function.",
    ])
    for a in genome["agents"]:
        if random.random() < rate:
            mod = random.choice(modifiers)
            if mod not in a.get("prompt", ""):
                a["prompt"] = (a.get("prompt", "") + mod).strip()
                print(f"[mutate-prompt] {a['id']}")

    # Novelty governor (simple variance-based)
    if len(scores) >= 3:
        vals = list(scores.values())
        mean = sum(vals) / len(vals)
        var = sum((x - mean) ** 2 for x in vals) / len(vals)
        if var < 0.8:  # too convergent → raise mutation pressure
            genome["mutation_rate"] = min(0.35, rate + 0.03)
        elif var > 4.0:  # too chaotic → lower
            genome["mutation_rate"] = max(0.05, rate - 0.02)

    # History
    genome.setdefault("history", []).append({
        "generation": gen,
        "scores": scores,
        "average": round(sum(scores.values()) / max(1, len(scores)), 2),
        "code_outcomes": code_outcomes[:5],
        "agent_count": len(genome["agents"]),
    })
    # Keep history from exploding
    if len(genome["history"]) > 80:
        genome["history"] = genome["history"][-60:]

    save_genome(genome)

# ---------------------------------------------------------------------------
# Git (optional)
# ---------------------------------------------------------------------------

def git_commit_push(label: str, message: str) -> None:
    if not USE_GIT or DRY_RUN:
        return
    try:
        subprocess.run(["git", "add", "-A"], cwd=BASE, check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        msg = f"[{label}] {message}"[:200]
        subprocess.run(["git", "commit", "-m", msg], cwd=BASE, check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["git", "push"], cwd=BASE, check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# One generation
# ---------------------------------------------------------------------------

def run_generation(genome: Dict) -> Optional[Dict]:
    if not running:
        return None

    gen = genome.get("generation", 0) + 1
    topic = genome.get("topic", "open-ended evolutionary improvement of the substrate")
    agents = list(genome.get("agents", []))
    if not agents:
        print("[error] no agents in genome")
        return None

    # Execution order
    order = genome.get("execution_order", "shuffle")
    if order == "shuffle":
        random.shuffle(agents)
    else:
        # keep listed order if present
        pass

    print(f"\n=== Generation {gen} | topic: {topic[:60]}... | agents: {len(agents)} ===")

    recent = load_recent_log(6)
    contributions: List[Tuple[str, str]] = []
    all_code_outcomes: List[str] = []
    agent_ids = [a["id"] for a in agents if a["id"] != "critic"]

    # Run non-critic agents
    for agent in agents:
        if not running:
            break
        aid = agent["id"]
        if aid == "critic":
            continue

        print(f"  → {aid} ...")
        try:
            prompt = build_agent_prompt(agent, topic, recent, genome)
            raw = llm_generate(prompt)
            text = strip_markdown(raw)

            # Code extraction & write
            blocks = extract_code_blocks(raw)
            outcomes = write_code_files(blocks, genome)
            all_code_outcomes.extend(outcomes)

            # Self patches
            patch_results = apply_self_patches(raw, genome)
            all_code_outcomes.extend(patch_results)

            # Genome extension
            ext = extend_genome(raw, genome)
            if ext:
                all_code_outcomes.extend(ext)

            append_log("agent", aid, text)
            contributions.append((aid, text))
            speak(aid, text)
            git_commit_push(aid, text[:80])

            # Keep recent context fresh
            recent.append({"agent": aid, "text": text})
            if len(recent) > 8:
                recent = recent[-6:]

        except Exception as e:
            print(f"  ! {aid} failed: {e}")
            traceback.print_exc()
            append_log("error", aid, str(e))
            contributions.append((aid, f"[error: {e}]"))

    if not running:
        return genome

    # Critic turn
    critic = next((a for a in agents if a["id"] == "critic"), None)
    if critic is None:
        # synthesize a minimal critic
        scores = {aid: 5.0 for aid, _ in contributions}
    else:
        print("  → critic ...")
        try:
            cprompt = build_critic_prompt(topic, contributions, all_code_outcomes, genome)
            craw = llm_generate(cprompt)
            scores = extract_scores(craw, agent_ids)
            scores = inject_noise(scores, genome.get("mutation_rate", 0.12))
            append_log("critic", "critic", craw)
            speak("critic", craw[:400])
            git_commit_push("critic", "scores")
        except Exception as e:
            print(f"  ! critic failed: {e}")
            scores = {aid: 5.0 for aid, _ in contributions}

    # Evolve
    update_genome_after_generation(genome, scores, all_code_outcomes)
    update_metrics(genome, scores, {"code_outcomes_count": len(all_code_outcomes)})

    print(f"  scores: { {k: round(v,1) for k,v in scores.items()} }")
    print(f"  agents now: {len(genome.get('agents', []))}")

    return genome

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    global DRY_RUN, USE_VOICE, USE_GIT, MAX_GENERATIONS

    parser = argparse.ArgumentParser(description="T3-T4-T5 Swarm (Hardened)")
    parser.add_argument("--dry-run", action="store_true", help="No disk writes, no git, no voice")
    parser.add_argument("--no-voice", action="store_true")
    parser.add_argument("--no-git", action="store_true")
    parser.add_argument("--max-generations", type=int, default=None)
    args = parser.parse_args()

    DRY_RUN = args.dry_run
    USE_VOICE = not args.no_voice and not DRY_RUN
    USE_GIT = not args.no_git and not DRY_RUN
    MAX_GENERATIONS = args.max_generations

    print("T3-T4-T5 Swarm (Hardened)")
    print(f"  dry-run={DRY_RUN}  voice={USE_VOICE}  git={USE_GIT}")
    print(f"  genome: {GENOME_FILE}")

    genome = load_genome()
    print(f"  starting at generation {genome.get('generation', 0)} with {len(genome.get('agents', []))} agents")

    gen_count = 0
    while running:
        genome = run_generation(genome)
        if genome is None:
            break
        gen_count += 1
        if MAX_GENERATIONS and gen_count >= MAX_GENERATIONS:
            print(f"[limit] reached --max-generations {MAX_GENERATIONS}")
            break
        time.sleep(1.5)

    print("\n[stop] Swarm halted.")
    if not DRY_RUN:
        git_commit_push("system", "Swarm stopped")


if __name__ == "__main__":
    main()
