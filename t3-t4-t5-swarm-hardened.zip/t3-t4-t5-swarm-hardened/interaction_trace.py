#!/usr/bin/env python3
"""
Adaptive compression-based emergence score.

Tracks a stream of events and computes how much better the real trace
compresses versus a shuffled baseline. Window size adapts to variance.
Useful as an external-ish novelty / structure signal.
"""

from collections import deque
from typing import Any, Deque, List
import lzma
import random


class AdaptiveCompressionEmergence:
    def __init__(self, base_window: int = 100, min_window: int = 10, max_window: int = 10000):
        self.base_window = base_window
        self.min_window = min_window
        self.max_window = max_window
        self.window = base_window
        self.trace: Deque[str] = deque(maxlen=self.window)
        self.bpe_history: Deque[float] = deque(maxlen=50)
        self.variance_history: Deque[float] = deque(maxlen=20)
        self.emergence_score = 0.0

    def observe(self, event: Any) -> float:
        self.trace.append(str(event))
        if len(self.trace) < 10:
            return 0.0

        joined = "|".join(self.trace)
        compressed = lzma.compress(joined.encode("utf-8"), preset=0)
        bpe = (len(compressed) * 8) / max(1, len(self.trace))
        self.bpe_history.append(bpe)

        if len(self.bpe_history) >= 10:
            recent = list(self.bpe_history)[-10:]
            mean = sum(recent) / len(recent)
            var = sum((x - mean) ** 2 for x in recent) / len(recent)
            self.variance_history.append(var)

            # Adaptive window
            if var > 2.0 and self.window < self.max_window:
                self._resize(min(self.window * 2, self.max_window))
            elif var < 0.5 and self.window > self.min_window:
                self._resize(max(self.window // 2, self.min_window))

            baseline = self._shuffled_baseline()
            self.emergence_score = max(0.0, baseline - bpe)

        return self.emergence_score

    def _shuffled_baseline(self) -> float:
        if len(self.trace) < 10:
            return 0.0
        items = list(self.trace)
        random.shuffle(items)
        joined = "|".join(items)
        compressed = lzma.compress(joined.encode("utf-8"), preset=0)
        return (len(compressed) * 8) / len(items)

    def _resize(self, new_size: int) -> None:
        self.window = new_size
        old = list(self.trace)
        self.trace = deque(old[-new_size:], maxlen=new_size)


if __name__ == "__main__":
    mon = AdaptiveCompressionEmergence()
    for i in range(30):
        score = mon.observe(f"event-{i % 7}-{i}")
        if i % 5 == 0:
            print(f"i={i} emergence_score={score:.3f} window={mon.window}")
