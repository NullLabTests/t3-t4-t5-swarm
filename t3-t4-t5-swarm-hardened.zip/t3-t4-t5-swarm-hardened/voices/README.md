# Voice models

Piper TTS `.onnx` voice models are large (~60 MB each) and are **not** included in this package.

Download from:
https://huggingface.co/rhasspy/piper-voices/tree/main/en

Recommended set (matching the original VOICE_MAP):

- en_US-lessac-medium.onnx (+ .json)
- en_US-amy-medium.onnx (+ .json)
- en_GB-alan-medium.onnx (+ .json)   # or similar
- en_US-southern_english_male-medium.onnx (or closest)

Place the files in this directory and create the expected names if needed:

```bash
# example
ln -s en_US-lessac-medium.onnx lessac.onnx
ln -s en_US-lessac-medium.onnx.json lessac.onnx.json
# etc.
```

The engine falls back silently if a voice is missing. Use `--no-voice` for headless runs.
